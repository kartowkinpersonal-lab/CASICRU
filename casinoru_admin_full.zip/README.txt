
CasinoRu — full package
Files:
- index.html  (main game)
- admin.html  (admin panel)
- styles.css
- script.js

Admin features:
- login with password admin123
- add funds / set balance / ban / unban users
- set jackpot
- export/import users.json
- admin writes to localStorage and posts messages to index.html (works if pages open in same origin).

Bonus: popолнение 100..10000 once per hour per user.
Sounds: embedded short beeps; you can replace audio src with links to your GitHub files for better audio.
